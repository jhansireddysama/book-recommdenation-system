"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, Star, Heart, DollarSign } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { BookService } from "../lib/book-service"

interface GenreRecommendationsProps {
  genre: string
  title: string
  limit?: number
}

export function GenreRecommendations({ genre, title, limit = 6 }: GenreRecommendationsProps) {
  const [books, setBooks] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadGenreBooks()
  }, [genre])

  const loadGenreBooks = async () => {
    try {
      setIsLoading(true)
      const genreBooks = await BookService.getBooksByGenre(genre)
      setBooks(genreBooks.slice(0, limit))
    } catch (error) {
      console.error(`Error loading ${genre} books:`, error)
    } finally {
      setIsLoading(false)
    }
  }

  const addToWishlist = (bookId: string) => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const wishlist = currentUser.wishlist || []

    if (!wishlist.includes(bookId)) {
      wishlist.push(bookId)
      currentUser.wishlist = wishlist
      localStorage.setItem("currentUser", JSON.stringify(currentUser))

      // Update in users array
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
      if (userIndex !== -1) {
        users[userIndex] = currentUser
        localStorage.setItem("users", JSON.stringify(users))
      }
    }
  }

  if (isLoading) {
    return (
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-6">{title}</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: limit }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="aspect-[3/4] bg-gray-200 rounded-lg mb-3" />
                <div className="h-4 bg-gray-200 rounded mb-2" />
                <div className="h-3 bg-gray-200 rounded w-2/3" />
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>
    )
  }

  if (books.length === 0) {
    return null
  }

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {books.map((book) => (
          <Card key={book.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-3 flex items-center justify-center overflow-hidden">
                {book.imageUrl || book.thumbnailUrl ? (
                  <Image
                    src={book.imageUrl || book.thumbnailUrl}
                    alt={book.title}
                    width={200}
                    height={267}
                    className="object-cover w-full h-full"
                    onError={(e) => {
                      e.currentTarget.style.display = "none"
                      e.currentTarget.nextElementSibling?.classList.remove("hidden")
                    }}
                  />
                ) : null}
                <div
                  className={`flex items-center justify-center w-full h-full ${book.imageUrl || book.thumbnailUrl ? "hidden" : ""}`}
                >
                  <BookOpen className="h-12 w-12 text-purple-600" />
                </div>
              </div>
              <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
              <CardDescription>by {book.author}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 mr-1" />
                    <span className="text-sm font-medium">{book.rating.toFixed(1)}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {book.language === "en" ? "English" : book.language}
                  </Badge>
                </div>

                {book.price && (
                  <div className="flex items-center text-green-600">
                    <DollarSign className="h-4 w-4 mr-1" />
                    <span className="font-medium text-sm">${book.price.amount}</span>
                  </div>
                )}

                <div className="flex flex-wrap gap-1">
                  {book.genres.slice(0, 2).map((bookGenre: string) => (
                    <Badge key={bookGenre} variant="secondary" className="text-xs">
                      {bookGenre}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex space-x-2">
                <Link href={`/book/${book.id}`} className="flex-1">
                  <Button size="sm" className="w-full">
                    View Details
                  </Button>
                </Link>
                <Button size="sm" variant="outline" onClick={() => addToWishlist(book.id)}>
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
