"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { BookOpen, BookMarked, Star, ArrowLeft, Play, CheckCircle, Clock, Search } from "lucide-react"
import Link from "next/link"
import { booksData } from "../lib/books-data"

export default function MyBooksPage() {
  const [myBooks, setMyBooks] = useState<any[]>([])
  const [currentUser, setCurrentUser] = useState<any>(null)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (user) {
      const userData = JSON.parse(user)
      setCurrentUser(userData)

      const bookIds = userData.myBooks || []
      const books = booksData
        .filter((book) => bookIds.includes(book.id))
        .map((book) => {
          // Get reading progress for each book
          const progress = localStorage.getItem(`reading_progress_${book.id}`)
          const progressData = progress ? JSON.parse(progress) : { percentage: 0, currentPage: 1 }

          return {
            ...book,
            readingProgress: progressData.percentage,
            currentPage: progressData.currentPage,
            isCompleted: progressData.percentage >= 100,
          }
        })
      setMyBooks(books)
    }
  }, [])

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Please log in to view your books</p>
          <Link href="/login">
            <Button className="mt-4">Go to Login</Button>
          </Link>
        </div>
      </div>
    )
  }

  const inProgressBooks = myBooks.filter((book) => book.readingProgress > 0 && !book.isCompleted)
  const completedBooks = myBooks.filter((book) => book.isCompleted)
  const notStartedBooks = myBooks.filter((book) => book.readingProgress === 0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <BookMarked className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">My Books</span>
            <Badge variant="secondary">{myBooks.length} books</Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {myBooks.length === 0 ? (
          <div className="text-center py-12">
            <BookMarked className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No books in your library</h3>
            <p className="text-gray-600 mb-6">Add books to start building your personal library</p>
            <Link href="/search">
              <Button>
                <Search className="h-4 w-4 mr-2" />
                Browse Books
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Currently Reading */}
            {inProgressBooks.length > 0 && (
              <section>
                <div className="flex items-center mb-6">
                  <Play className="h-6 w-6 text-green-600 mr-2" />
                  <h2 className="text-2xl font-bold">Currently Reading</h2>
                  <Badge variant="secondary" className="ml-2">
                    {inProgressBooks.length}
                  </Badge>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {inProgressBooks.map((book) => (
                    <Card key={book.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="aspect-[3/4] bg-gradient-to-br from-green-100 to-blue-100 rounded-lg mb-3 flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-green-600" />
                        </div>
                        <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
                        <CardDescription>by {book.author}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span>Progress</span>
                              <span>{Math.round(book.readingProgress)}%</span>
                            </div>
                            <Progress value={book.readingProgress} />
                            <div className="text-xs text-gray-600">
                              Page {book.currentPage} of {book.totalPages || 300}
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              <span className="text-sm font-medium">{book.rating}</span>
                            </div>
                            <Badge variant="outline">{book.genres[0]}</Badge>
                          </div>

                          <Link href={`/book/${book.id}`}>
                            <Button size="sm" className="w-full">
                              <Play className="h-4 w-4 mr-2" />
                              Continue Reading
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* Completed Books */}
            {completedBooks.length > 0 && (
              <section>
                <div className="flex items-center mb-6">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
                  <h2 className="text-2xl font-bold">Completed</h2>
                  <Badge variant="secondary" className="ml-2">
                    {completedBooks.length}
                  </Badge>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {completedBooks.map((book) => (
                    <Card key={book.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="aspect-[3/4] bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg mb-3 flex items-center justify-center relative">
                          <BookOpen className="h-12 w-12 text-green-600" />
                          <CheckCircle className="absolute top-2 right-2 h-6 w-6 text-green-600 bg-white rounded-full" />
                        </div>
                        <CardTitle className="text-base line-clamp-2">{book.title}</CardTitle>
                        <CardDescription className="text-sm">by {book.author}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              <span className="text-sm font-medium">{book.rating}</span>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {book.genres[0]}
                            </Badge>
                          </div>
                          <Link href={`/book/${book.id}`}>
                            <Button size="sm" variant="outline" className="w-full">
                              View Details
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* Not Started */}
            {notStartedBooks.length > 0 && (
              <section>
                <div className="flex items-center mb-6">
                  <Clock className="h-6 w-6 text-gray-600 mr-2" />
                  <h2 className="text-2xl font-bold">To Read</h2>
                  <Badge variant="secondary" className="ml-2">
                    {notStartedBooks.length}
                  </Badge>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {notStartedBooks.map((book) => (
                    <Card key={book.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="aspect-[3/4] bg-gradient-to-br from-gray-100 to-blue-100 rounded-lg mb-3 flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-gray-600" />
                        </div>
                        <CardTitle className="text-base line-clamp-2">{book.title}</CardTitle>
                        <CardDescription className="text-sm">by {book.author}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              <span className="text-sm font-medium">{book.rating}</span>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {book.genres[0]}
                            </Badge>
                          </div>
                          <Link href={`/book/${book.id}`}>
                            <Button size="sm" className="w-full">
                              <Play className="h-4 w-4 mr-2" />
                              Start Reading
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
