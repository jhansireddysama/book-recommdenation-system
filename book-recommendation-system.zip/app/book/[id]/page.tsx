"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BookOpen,
  Star,
  Heart,
  ArrowLeft,
  Share2,
  Clock,
  Calendar,
  Globe,
  User,
  BookMarked,
  Play,
  Pause,
  RotateCcw,
  DollarSign,
  ExternalLink,
  Eye,
  ShoppingCart,
} from "lucide-react"
import Link from "next/link"
import { BookService } from "../../lib/book-service"
import Image from "next/image"

export default function BookDetailsPage({ params }: { params: { id: string } }) {
  const [book, setBook] = useState<any>(null)
  const [isInWishlist, setIsInWishlist] = useState(false)
  const [isInMyBooks, setIsInMyBooks] = useState(false)
  const [readingProgress, setReadingProgress] = useState(0)
  const [isReading, setIsReading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [similarBooks, setSimilarBooks] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadBookDetails()
  }, [params.id])

  const loadBookDetails = async () => {
    try {
      setIsLoading(true)
      const bookId = params.id
      const foundBook = await BookService.getBookById(bookId)

      setBook(foundBook)

      if (foundBook) {
        const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
        setIsInWishlist(currentUser.wishlist?.includes(bookId) || false)
        setIsInMyBooks(currentUser.myBooks?.includes(bookId) || false)

        // Get reading progress
        const progress = localStorage.getItem(`reading_progress_${bookId}`)
        if (progress) {
          const progressData = JSON.parse(progress)
          setReadingProgress(progressData.percentage)
          setCurrentPage(progressData.currentPage)
        }

        // Load similar books based on genres
        loadSimilarBooks(foundBook.genres)
      }
    } catch (error) {
      console.error("Error loading book details:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const loadSimilarBooks = async (genres: string[]) => {
    try {
      const similar: any[] = []

      // Get books from same genres
      for (const genre of genres.slice(0, 2)) {
        const genreBooks = await BookService.getBooksByGenre(genre)
        similar.push(...genreBooks.filter((b) => b.id !== params.id).slice(0, 3))
      }

      // Remove duplicates and limit results
      const uniqueSimilar = similar
        .filter((book, index, self) => index === self.findIndex((b) => b.id === book.id))
        .slice(0, 6)

      setSimilarBooks(uniqueSimilar)
    } catch (error) {
      console.error("Error loading similar books:", error)
    }
  }

  const toggleWishlist = () => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const wishlist = currentUser.wishlist || []
    const bookId = params.id

    if (isInWishlist) {
      currentUser.wishlist = wishlist.filter((id: string) => id !== bookId)
    } else {
      currentUser.wishlist = [...wishlist, bookId]
    }

    localStorage.setItem("currentUser", JSON.stringify(currentUser))
    setIsInWishlist(!isInWishlist)
  }

  const addToMyBooks = () => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const myBooks = currentUser.myBooks || []
    const bookId = params.id

    if (!myBooks.includes(bookId)) {
      currentUser.myBooks = [...myBooks, bookId]
      localStorage.setItem("currentUser", JSON.stringify(currentUser))
      setIsInMyBooks(true)
    }
  }

  const startReading = () => {
    addToMyBooks()
    setIsReading(true)

    // Simulate reading progress
    const interval = setInterval(() => {
      setCurrentPage((prev) => {
        const newPage = prev + 1
        const progress = Math.min((newPage / (book?.totalPages || 300)) * 100, 100)
        setReadingProgress(progress)

        // Save progress
        localStorage.setItem(
          `reading_progress_${params.id}`,
          JSON.stringify({
            percentage: progress,
            currentPage: newPage,
            lastRead: new Date().toISOString(),
          }),
        )

        if (progress >= 100) {
          clearInterval(interval)
          setIsReading(false)

          // Mark as completed
          const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
          currentUser.readingProgress = {
            ...currentUser.readingProgress,
            booksRead: (currentUser.readingProgress?.booksRead || 0) + 1,
          }
          localStorage.setItem("currentUser", JSON.stringify(currentUser))
        }

        return newPage
      })
    }, 100) // Fast simulation for demo

    // Stop after 10 seconds for demo
    setTimeout(() => {
      clearInterval(interval)
      setIsReading(false)
    }, 10000)
  }

  const pauseReading = () => {
    setIsReading(false)
  }

  const resetProgress = () => {
    setReadingProgress(0)
    setCurrentPage(1)
    localStorage.removeItem(`reading_progress_${params.id}`)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600 animate-pulse" />
          <p className="text-gray-600">Loading book details...</p>
        </div>
      </div>
    )
  }

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Book not found</p>
          <Link href="/dashboard">
            <Button className="mt-4">Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
              <BookOpen className="h-6 w-6 text-blue-600" />
              <span className="text-xl font-bold">Book Details</span>
            </div>
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Book Cover & Actions */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="aspect-[3/4] mb-6 flex items-center justify-center bg-gray-100 rounded-lg overflow-hidden">
                  {book.imageUrl || book.thumbnailUrl ? (
                    <Image
                      src={book.imageUrl || book.thumbnailUrl}
                      alt={book.title}
                      width={300}
                      height={400}
                      className="object-cover w-full h-full"
                      onError={(e) => {
                        // Fallback to placeholder if image fails to load
                        e.currentTarget.style.display = "none"
                        e.currentTarget.nextElementSibling?.classList.remove("hidden")
                      }}
                    />
                  ) : null}
                  <div
                    className={`flex items-center justify-center w-full h-full ${book.imageUrl || book.thumbnailUrl ? "hidden" : ""}`}
                  >
                    <BookOpen className="h-24 w-24 text-blue-600" />
                  </div>
                </div>

                {/* Price Information */}
                {book.price && (
                  <div className="mb-4 p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 text-green-600 mr-1" />
                        <span className="font-semibold text-green-800">${book.price.amount}</span>
                        {book.price.retailPrice && book.price.retailPrice !== book.price.amount && (
                          <span className="text-sm text-gray-500 line-through ml-2">${book.price.retailPrice}</span>
                        )}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {book.price.currency}
                      </Badge>
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Button className="flex-1" onClick={startReading} disabled={isReading}>
                      {isReading ? (
                        <>
                          <Pause className="h-4 w-4 mr-2" />
                          Reading...
                        </>
                      ) : readingProgress > 0 ? (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Continue Reading
                        </>
                      ) : (
                        <>
                          <BookOpen className="h-4 w-4 mr-2" />
                          Start Reading
                        </>
                      )}
                    </Button>
                    {isReading && (
                      <Button variant="outline" onClick={pauseReading}>
                        <Pause className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  {readingProgress > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Reading Progress</span>
                        <span>{Math.round(readingProgress)}%</span>
                      </div>
                      <Progress value={readingProgress} />
                      <div className="flex items-center justify-between text-xs text-gray-600">
                        <span>
                          Page {currentPage} of {book.totalPages || 300}
                        </span>
                        <Button variant="ghost" size="sm" onClick={resetProgress} className="h-auto p-1">
                          <RotateCcw className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1" onClick={toggleWishlist}>
                      <Heart className={`h-4 w-4 mr-2 ${isInWishlist ? "fill-current text-red-500" : ""}`} />
                      {isInWishlist ? "In Wishlist" : "Add to Wishlist"}
                    </Button>
                    {!isInMyBooks && (
                      <Button variant="outline" onClick={addToMyBooks}>
                        <BookMarked className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  {/* Buy/Preview Links */}
                  {book.availability && (
                    <div className="space-y-2">
                      {book.availability.buyLink && (
                        <Button variant="outline" className="w-full" asChild>
                          <a href={book.availability.buyLink} target="_blank" rel="noopener noreferrer">
                            <ShoppingCart className="h-4 w-4 mr-2" />
                            Buy Book
                            <ExternalLink className="h-3 w-3 ml-2" />
                          </a>
                        </Button>
                      )}
                      {book.availability.previewLink && (
                        <Button variant="ghost" className="w-full" asChild>
                          <a href={book.availability.previewLink} target="_blank" rel="noopener noreferrer">
                            <Eye className="h-4 w-4 mr-2" />
                            Preview Book
                            <ExternalLink className="h-3 w-3 ml-2" />
                          </a>
                        </Button>
                      )}
                    </div>
                  )}

                  {isInMyBooks && (
                    <Badge variant="secondary" className="w-full justify-center">
                      <BookMarked className="h-4 w-4 mr-2" />
                      In My Library
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Book Information */}
          <div className="lg:col-span-2">
            <div className="space-y-6">
              {/* Basic Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-3xl">{book.title}</CardTitle>
                  <CardDescription className="text-lg">
                    by {book.authors ? book.authors.join(", ") : book.author}
                  </CardDescription>
                  <div className="flex items-center space-x-4 pt-2">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-500 mr-1" />
                      <span className="font-medium">{book.rating.toFixed(1)}</span>
                      <span className="text-gray-600 ml-1">({book.reviews.toLocaleString()} reviews)</span>
                    </div>
                    <Badge variant="outline">{book.language === "en" ? "English" : book.language}</Badge>
                    {book.availability?.isEbook && <Badge variant="secondary">E-book Available</Badge>}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center text-gray-600">
                      <Calendar className="h-4 w-4 mr-2" />
                      Published: {book.publishedYear}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Clock className="h-4 w-4 mr-2" />
                      {book.totalPages} pages
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Globe className="h-4 w-4 mr-2" />
                      ISBN: {book.isbn}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <User className="h-4 w-4 mr-2" />
                      Publisher: {book.publisher || "Unknown"}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium">Genres</h4>
                    <div className="flex flex-wrap gap-2">
                      {book.genres.map((genre: string) => (
                        <Badge key={genre} variant="secondary">
                          {genre}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tabs for Description, Reviews, etc. */}
              <Card>
                <Tabs defaultValue="description" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="description">Description</TabsTrigger>
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="similar">Similar Books</TabsTrigger>
                  </TabsList>

                  <TabsContent value="description" className="p-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">About this book</h3>
                      <div className="prose max-w-none">
                        <p className="text-gray-700 leading-relaxed">
                          {book.description ? (
                            <span
                              dangerouslySetInnerHTML={{
                                __html: book.description.replace(/<[^>]*>/g, ""),
                              }}
                            />
                          ) : (
                            `${book.title} is a captivating ${book.genres[0]?.toLowerCase()} by ${book.author}. This engaging story takes readers on an unforgettable journey through compelling characters and intricate plot developments. With its masterful storytelling and rich narrative, this book has earned critical acclaim and reader praise alike.`
                          )}
                        </p>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 pt-4">
                        <div>
                          <h4 className="font-medium mb-2">Key Features</h4>
                          <ul className="text-sm text-gray-600 space-y-1">
                            <li>
                              •{" "}
                              {book.authors
                                ? `${book.authors.length} author${book.authors.length > 1 ? "s" : ""}`
                                : "Acclaimed author"}
                            </li>
                            <li>• {book.rating >= 4.0 ? "Highly rated" : "Well reviewed"}</li>
                            <li>• {book.genres[0]} bestseller</li>
                            <li>• Available in multiple formats</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">Reading Info</h4>
                          <ul className="text-sm text-gray-600 space-y-1">
                            <li>• Estimated reading time: {Math.ceil(book.totalPages / 50)} hours</li>
                            <li>• {book.detailedInfo?.maturityRating || "General"} audience</li>
                            <li>• {book.detailedInfo?.printType || "Book"} format</li>
                            <li>• Language: {book.language === "en" ? "English" : book.language}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="details" className="p-6">
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold">Book Details</h3>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <h4 className="font-medium">Publication Information</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Publisher:</span>
                              <span>{book.publisher || "Unknown"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Publication Year:</span>
                              <span>{book.publishedYear}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Pages:</span>
                              <span>{book.totalPages}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Language:</span>
                              <span>{book.language === "en" ? "English" : book.language}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">ISBN:</span>
                              <span className="font-mono text-xs">{book.isbn}</span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <h4 className="font-medium">Availability & Pricing</h4>
                          <div className="space-y-2 text-sm">
                            {book.price && (
                              <div className="flex justify-between">
                                <span className="text-gray-600">Price:</span>
                                <span className="font-semibold">
                                  ${book.price.amount} {book.price.currency}
                                </span>
                              </div>
                            )}
                            <div className="flex justify-between">
                              <span className="text-gray-600">E-book:</span>
                              <span>{book.availability?.isEbook ? "Available" : "Not Available"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Print:</span>
                              <span>{book.availability?.isPrint ? "Available" : "Not Available"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Rating:</span>
                              <span>{book.rating.toFixed(1)}/5.0</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Reviews:</span>
                              <span>{book.reviews.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {book.detailedInfo?.categories && book.detailedInfo.categories.length > 0 && (
                        <div>
                          <h4 className="font-medium mb-2">Categories</h4>
                          <div className="flex flex-wrap gap-2">
                            {book.detailedInfo.categories.map((category: string) => (
                              <Badge key={category} variant="outline" className="text-xs">
                                {category}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="similar" className="p-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Similar Books You Might Like</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        {similarBooks.map((similarBook) => (
                          <Link key={similarBook.id} href={`/book/${similarBook.id}`}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer">
                              <CardContent className="p-4">
                                <div className="flex space-x-3">
                                  <div className="w-16 h-20 bg-gray-100 rounded flex items-center justify-center flex-shrink-0 overflow-hidden">
                                    {similarBook.thumbnailUrl ? (
                                      <Image
                                        src={similarBook.thumbnailUrl || "/placeholder.svg"}
                                        alt={similarBook.title}
                                        width={64}
                                        height={80}
                                        className="object-cover w-full h-full"
                                      />
                                    ) : (
                                      <BookOpen className="h-6 w-6 text-blue-600" />
                                    )}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <h4 className="font-medium line-clamp-2 mb-1">{similarBook.title}</h4>
                                    <p className="text-sm text-gray-600 mb-2">by {similarBook.author}</p>
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center">
                                        <Star className="h-3 w-3 text-yellow-500 mr-1" />
                                        <span className="text-xs">{similarBook.rating.toFixed(1)}</span>
                                      </div>
                                      <Badge variant="outline" className="text-xs">
                                        {similarBook.genres[0]}
                                      </Badge>
                                    </div>
                                    {similarBook.price && (
                                      <div className="text-xs text-green-600 font-medium mt-1">
                                        ${similarBook.price.amount}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </Link>
                        ))}
                      </div>
                      {similarBooks.length === 0 && (
                        <p className="text-gray-600 text-center py-8">Loading similar books...</p>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
