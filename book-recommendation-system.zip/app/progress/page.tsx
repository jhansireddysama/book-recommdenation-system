"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Award, Target, Flame, Calendar, ArrowLeft, Trophy, Star, TrendingUp } from "lucide-react"
import Link from "next/link"

const badges = [
  { id: 1, name: "First Book", description: "Read your first book", icon: BookOpen, earned: true },
  { id: 2, name: "Speed Reader", description: "Read 5 books in a month", icon: Flame, earned: false },
  { id: 3, name: "Bookworm", description: "Read 25 books", icon: Trophy, earned: false },
  { id: 4, name: "Genre Explorer", description: "Read books from 5 different genres", icon: Star, earned: true },
  { id: 5, name: "Consistent Reader", description: "Read for 30 days straight", icon: Calendar, earned: false },
  { id: 6, name: "Goal Crusher", description: "Achieve your yearly reading goal", icon: Target, earned: false },
]

export default function ProgressPage() {
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [stats, setStats] = useState({
    booksRead: 0,
    currentStreak: 0,
    longestStreak: 0,
    totalPages: 0,
    readingGoal: 12,
    genresExplored: 0,
    averageRating: 0,
  })

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (user) {
      const userData = JSON.parse(user)
      setCurrentUser(userData)

      // Calculate stats
      const progress = userData.readingProgress || {}
      const preferences = userData.preferences || {}

      setStats({
        booksRead: progress.booksRead || 0,
        currentStreak: progress.currentStreak || 0,
        longestStreak: progress.longestStreak || 0,
        totalPages: progress.totalPages || 0,
        readingGoal: preferences.readingGoal || 12,
        genresExplored: preferences.genres?.length || 0,
        averageRating: 4.2, // Mock average rating
      })
    }
  }, [])

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Please log in to view your progress</p>
          <Link href="/login">
            <Button className="mt-4">Go to Login</Button>
          </Link>
        </div>
      </div>
    )
  }

  const goalProgress = (stats.booksRead / stats.readingGoal) * 100

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <Award className="h-6 w-6 text-purple-600" />
            <span className="text-xl font-bold">Reading Progress</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Stats Overview */}
          <div className="lg:col-span-2 space-y-6">
            {/* Reading Goal */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2 text-green-600" />
                  2024 Reading Goal
                </CardTitle>
                <CardDescription>
                  {stats.booksRead} of {stats.readingGoal} books completed
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={goalProgress} className="h-3" />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>{Math.round(goalProgress)}% complete</span>
                    <span>{stats.readingGoal - stats.booksRead} books remaining</span>
                  </div>
                  {goalProgress >= 100 && <Badge className="bg-green-100 text-green-800">🎉 Goal Achieved!</Badge>}
                </div>
              </CardContent>
            </Card>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Reading Streak</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <Flame className="h-8 w-8 text-orange-500 mr-2" />
                      <div>
                        <div className="text-2xl font-bold">{stats.currentStreak}</div>
                        <div className="text-sm text-gray-600">Current</div>
                      </div>
                    </div>
                    <div className="border-l pl-4">
                      <div className="text-lg font-semibold">{stats.longestStreak}</div>
                      <div className="text-sm text-gray-600">Longest</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Pages Read</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <BookOpen className="h-8 w-8 text-blue-500 mr-3" />
                    <div>
                      <div className="text-2xl font-bold">{stats.totalPages.toLocaleString()}</div>
                      <div className="text-sm text-gray-600">Total pages</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Genres Explored</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <Star className="h-8 w-8 text-purple-500 mr-3" />
                    <div>
                      <div className="text-2xl font-bold">{stats.genresExplored}</div>
                      <div className="text-sm text-gray-600">Different genres</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Average Rating</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-green-500 mr-3" />
                    <div>
                      <div className="text-2xl font-bold">{stats.averageRating}</div>
                      <div className="text-sm text-gray-600">Book ratings</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Reading Activity</CardTitle>
                <CardDescription>Your reading activity over the past year</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-12 gap-1">
                  {Array.from({ length: 365 }, (_, i) => (
                    <div
                      key={i}
                      className={`w-3 h-3 rounded-sm ${
                        Math.random() > 0.7 ? "bg-green-500" : Math.random() > 0.5 ? "bg-green-300" : "bg-gray-200"
                      }`}
                      title={`Day ${i + 1}`}
                    />
                  ))}
                </div>
                <div className="flex items-center justify-between mt-4 text-sm text-gray-600">
                  <span>Less</span>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-gray-200 rounded-sm" />
                    <div className="w-3 h-3 bg-green-300 rounded-sm" />
                    <div className="w-3 h-3 bg-green-500 rounded-sm" />
                  </div>
                  <span>More</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Badges & Achievements */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="h-5 w-5 mr-2 text-purple-600" />
                  Achievements
                </CardTitle>
                <CardDescription>
                  {badges.filter((b) => b.earned).length} of {badges.length} badges earned
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {badges.map((badge) => {
                    const IconComponent = badge.icon
                    return (
                      <div
                        key={badge.id}
                        className={`flex items-center space-x-3 p-3 rounded-lg border ${
                          badge.earned ? "bg-purple-50 border-purple-200" : "bg-gray-50 border-gray-200 opacity-60"
                        }`}
                      >
                        <div className={`p-2 rounded-full ${badge.earned ? "bg-purple-100" : "bg-gray-100"}`}>
                          <IconComponent className={`h-5 w-5 ${badge.earned ? "text-purple-600" : "text-gray-400"}`} />
                        </div>
                        <div className="flex-1">
                          <div className={`font-medium ${badge.earned ? "text-gray-900" : "text-gray-500"}`}>
                            {badge.name}
                          </div>
                          <div className="text-sm text-gray-600">{badge.description}</div>
                        </div>
                        {badge.earned && (
                          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                            Earned
                          </Badge>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/search">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Find New Books
                  </Button>
                </Link>
                <Link href="/profile">
                  <Button variant="outline" className="w-full justify-start">
                    <Target className="h-4 w-4 mr-2" />
                    Update Reading Goal
                  </Button>
                </Link>
                <Link href="/my-books">
                  <Button variant="outline" className="w-full justify-start">
                    <Award className="h-4 w-4 mr-2" />
                    View My Library
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
