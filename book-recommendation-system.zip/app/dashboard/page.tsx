"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  BookOpen,
  Search,
  TrendingUp,
  Heart,
  User,
  Settings,
  Star,
  Award,
  Target,
  Flame,
  BookMarked,
  DollarSign,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { BookService } from "../lib/book-service"
import { GenreRecommendations } from "../components/genre-recommendations"

export default function DashboardPage() {
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [trendingBooks, setTrendingBooks] = useState<any[]>([])
  const [recommendedBooks, setRecommendedBooks] = useState<any[]>([])
  const [userGenres, setUserGenres] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (user) {
      const userData = JSON.parse(user)
      setCurrentUser(userData)
      setUserGenres(userData.preferences?.genres || [])
    }

    // Load trending and recommended books
    loadBooks()
  }, [])

  const loadBooks = async () => {
    try {
      setIsLoading(true)

      // Get trending books from API with real data
      const trending = await BookService.getTrendingBooks()
      setTrendingBooks(trending.slice(0, 6))

      // Get personalized recommendations if user is logged in
      const user = localStorage.getItem("currentUser")
      if (user) {
        const userData = JSON.parse(user)
        if (userData.preferences?.genres?.length > 0) {
          const recommended = await BookService.getPersonalizedRecommendations({
            genres: userData.preferences.genres,
            languages: userData.preferences.languages || ["en"],
          })
          setRecommendedBooks(recommended.slice(0, 6))
        } else {
          // If no preferences set, show popular books
          const popular = await BookService.getTrendingBooks()
          setRecommendedBooks(popular.slice(0, 6))
        }
      }
    } catch (error) {
      console.error("Error loading books:", error)
      // Fallback to local data
      const localBooks = BookService.getAllBooks()
      setTrendingBooks(localBooks.sort((a, b) => b.reviews - a.reviews).slice(0, 6))
      setRecommendedBooks(localBooks.sort((a, b) => b.rating - a.rating).slice(0, 6))
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = async () => {
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`
    }
  }

  const addToWishlist = (bookId: string) => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const wishlist = currentUser.wishlist || []

    if (!wishlist.includes(bookId)) {
      wishlist.push(bookId)
      currentUser.wishlist = wishlist
      localStorage.setItem("currentUser", JSON.stringify(currentUser))

      // Update in users array
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
      if (userIndex !== -1) {
        users[userIndex] = currentUser
        localStorage.setItem("users", JSON.stringify(users))
      }
    }
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Please log in to access your dashboard</p>
          <Link href="/login">
            <Button className="mt-4">Go to Login</Button>
          </Link>
        </div>
      </div>
    )
  }

  const BookCard = ({ book }: { book: any }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-2">
        <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-3 flex items-center justify-center overflow-hidden">
          {book.imageUrl || book.thumbnailUrl ? (
            <Image
              src={book.imageUrl || book.thumbnailUrl}
              alt={book.title}
              width={200}
              height={267}
              className="object-cover w-full h-full"
              onError={(e) => {
                e.currentTarget.style.display = "none"
                e.currentTarget.nextElementSibling?.classList.remove("hidden")
              }}
            />
          ) : null}
          <div
            className={`flex items-center justify-center w-full h-full ${book.imageUrl || book.thumbnailUrl ? "hidden" : ""}`}
          >
            <BookOpen className="h-12 w-12 text-blue-600" />
          </div>
        </div>
        <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
        <CardDescription>by {book.author}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-500 mr-1" />
              <span className="text-sm font-medium">{book.rating.toFixed(1)}</span>
            </div>
            <Badge variant="outline">{book.genres[0]}</Badge>
          </div>

          {book.price && (
            <div className="flex items-center text-green-600">
              <DollarSign className="h-4 w-4 mr-1" />
              <span className="font-medium">${book.price.amount}</span>
            </div>
          )}

          <div className="flex space-x-2">
            <Link href={`/book/${book.id}`} className="flex-1">
              <Button size="sm" className="w-full">
                View Details
              </Button>
            </Link>
            <Button size="sm" variant="outline" onClick={() => addToWishlist(book.id)}>
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold">ReadSphere</span>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-md mx-8">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search books, authors, genres..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Link href="/search">
                <Button variant="ghost" size="sm">
                  <Search className="h-4 w-4 mr-2" />
                  Advanced Search
                </Button>
              </Link>
              <Link href="/profile">
                <Avatar>
                  <AvatarFallback>{currentUser.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Welcome, {currentUser.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Books Read</span>
                    <Badge variant="secondary">{currentUser.readingProgress?.booksRead || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Current Streak</span>
                    <div className="flex items-center">
                      <Flame className="h-4 w-4 text-orange-500 mr-1" />
                      <span className="text-sm font-medium">{currentUser.readingProgress?.currentStreak || 0}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Reading Goal</span>
                    <div className="flex items-center">
                      <Target className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-sm font-medium">{currentUser.preferences?.readingGoal || 12}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Link href="/wishlist">
                    <Button variant="ghost" className="w-full justify-start">
                      <Heart className="h-4 w-4 mr-2" />
                      Wishlist
                    </Button>
                  </Link>
                  <Link href="/my-books">
                    <Button variant="ghost" className="w-full justify-start">
                      <BookMarked className="h-4 w-4 mr-2" />
                      My Books
                    </Button>
                  </Link>
                  <Link href="/progress">
                    <Button variant="ghost" className="w-full justify-start">
                      <Award className="h-4 w-4 mr-2" />
                      Reading Progress
                    </Button>
                  </Link>
                  <Link href="/profile">
                    <Button variant="ghost" className="w-full justify-start">
                      <Settings className="h-4 w-4 mr-2" />
                      Settings
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Trending Books */}
            <section>
              <div className="flex items-center mb-6">
                <TrendingUp className="h-6 w-6 text-orange-500 mr-2" />
                <h2 className="text-2xl font-bold">Trending Now</h2>
                <Badge variant="secondary" className="ml-2">
                  Real-time data
                </Badge>
              </div>

              {isLoading ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardHeader className="pb-2">
                        <div className="aspect-[3/4] bg-gray-200 rounded-lg mb-3" />
                        <div className="h-4 bg-gray-200 rounded mb-2" />
                        <div className="h-3 bg-gray-200 rounded w-2/3" />
                      </CardHeader>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {trendingBooks.map((book) => (
                    <BookCard key={book.id} book={book} />
                  ))}
                </div>
              )}
            </section>

            {/* Recommended Books */}
            {recommendedBooks.length > 0 && (
              <section>
                <div className="flex items-center mb-6">
                  <Star className="h-6 w-6 text-yellow-500 mr-2" />
                  <h2 className="text-2xl font-bold">Recommended for You</h2>
                  <Badge variant="secondary" className="ml-2">
                    Personalized
                  </Badge>
                </div>

                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <Card key={i} className="animate-pulse">
                        <CardHeader className="pb-2">
                          <div className="aspect-[3/4] bg-gray-200 rounded-lg mb-3" />
                          <div className="h-4 bg-gray-200 rounded mb-2" />
                          <div className="h-3 bg-gray-200 rounded w-2/3" />
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {recommendedBooks.map((book) => (
                      <BookCard key={book.id} book={book} />
                    ))}
                  </div>
                )}
              </section>
            )}

            {/* Genre-specific Recommendations */}
            {userGenres.length > 0 && !isLoading && (
              <div className="space-y-8">
                {userGenres.slice(0, 3).map((genre) => (
                  <GenreRecommendations key={genre} genre={genre} title={`Best ${genre} Books`} limit={6} />
                ))}
              </div>
            )}

            {/* Show popular genres if user hasn't selected any */}
            {userGenres.length === 0 && !isLoading && (
              <div className="space-y-8">
                <GenreRecommendations genre="Fiction" title="Popular Fiction" limit={6} />
                <GenreRecommendations genre="Science Fiction" title="Trending Science Fiction" limit={6} />
                <GenreRecommendations genre="Mystery" title="Best Mystery & Thriller" limit={6} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
