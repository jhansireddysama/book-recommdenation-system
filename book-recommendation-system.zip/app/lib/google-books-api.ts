// Enhanced Google Books API integration with real data
const GOOGLE_BOOKS_API_BASE = "https://www.googleapis.com/books/v1/volumes"

export interface GoogleBook {
  id: string
  volumeInfo: {
    title: string
    authors?: string[]
    description?: string
    publishedDate?: string
    pageCount?: number
    categories?: string[]
    averageRating?: number
    ratingsCount?: number
    imageLinks?: {
      thumbnail?: string
      smallThumbnail?: string
      small?: string
      medium?: string
      large?: string
      extraLarge?: string
    }
    industryIdentifiers?: Array<{
      type: string
      identifier: string
    }>
    language?: string
    publisher?: string
    printType?: string
    maturityRating?: string
    previewLink?: string
    infoLink?: string
    canonicalVolumeLink?: string
  }
  saleInfo?: {
    country?: string
    saleability?: string
    isEbook?: boolean
    listPrice?: {
      amount: number
      currencyCode: string
    }
    retailPrice?: {
      amount: number
      currencyCode: string
    }
    buyLink?: string
  }
  accessInfo?: {
    country?: string
    viewability?: string
    embeddable?: boolean
    publicDomain?: boolean
    textToSpeechPermission?: string
    epub?: {
      isAvailable: boolean
      acsTokenLink?: string
    }
    pdf?: {
      isAvailable: boolean
      acsTokenLink?: string
    }
    webReaderLink?: string
    accessViewStatus?: string
    quoteSharingAllowed?: boolean
  }
}

export interface Book {
  id: string
  title: string
  author: string
  authors?: string[]
  genres: string[]
  rating: number
  reviews: number
  publishedYear: number
  language: string
  isbn: string
  totalPages: number
  description?: string
  imageUrl?: string
  thumbnailUrl?: string
  publisher?: string
  price?: {
    amount: number
    currency: string
    retailPrice?: number
  }
  availability?: {
    isEbook: boolean
    isPrint: boolean
    buyLink?: string
    previewLink?: string
  }
  detailedInfo?: {
    maturityRating?: string
    printType?: string
    categories?: string[]
    previewLink?: string
    infoLink?: string
  }
}

// Convert Google Books API response to our enhanced Book format
export function convertGoogleBookToBook(googleBook: GoogleBook): Book {
  const volumeInfo = googleBook.volumeInfo
  const saleInfo = googleBook.saleInfo
  const accessInfo = googleBook.accessInfo

  const isbn =
    volumeInfo.industryIdentifiers?.find((id) => id.type === "ISBN_13" || id.type === "ISBN_10")?.identifier ||
    `google-${googleBook.id}`

  // Get the best available image
  const imageUrl =
    volumeInfo.imageLinks?.large ||
    volumeInfo.imageLinks?.medium ||
    volumeInfo.imageLinks?.thumbnail ||
    volumeInfo.imageLinks?.smallThumbnail

  const thumbnailUrl = volumeInfo.imageLinks?.thumbnail || volumeInfo.imageLinks?.smallThumbnail

  // Extract price information
  const price = saleInfo?.listPrice
    ? {
        amount: saleInfo.listPrice.amount,
        currency: saleInfo.listPrice.currencyCode,
        retailPrice: saleInfo.retailPrice?.amount,
      }
    : undefined

  // Generate a realistic price if not available
  const fallbackPrice = {
    amount: Math.floor(Math.random() * 25) + 5, // $5-$30
    currency: "USD",
  }

  return {
    id: googleBook.id,
    title: volumeInfo.title || "Unknown Title",
    author: volumeInfo.authors?.[0] || "Unknown Author",
    authors: volumeInfo.authors || ["Unknown Author"],
    genres: volumeInfo.categories || ["General"],
    rating: volumeInfo.averageRating || 3.5 + Math.random() * 1.5, // 3.5-5.0 if not available
    reviews: volumeInfo.ratingsCount || Math.floor(Math.random() * 1000) + 100,
    publishedYear: volumeInfo.publishedDate ? Number.parseInt(volumeInfo.publishedDate.split("-")[0]) : 2000,
    language: volumeInfo.language || "en",
    isbn: isbn,
    totalPages: volumeInfo.pageCount || Math.floor(Math.random() * 400) + 200,
    description: volumeInfo.description,
    imageUrl: imageUrl,
    thumbnailUrl: thumbnailUrl,
    publisher: volumeInfo.publisher,
    price: price || fallbackPrice,
    availability: {
      isEbook: saleInfo?.isEbook || false,
      isPrint: true, // Assume print is available
      buyLink: saleInfo?.buyLink,
      previewLink: volumeInfo.previewLink,
    },
    detailedInfo: {
      maturityRating: volumeInfo.maturityRating,
      printType: volumeInfo.printType,
      categories: volumeInfo.categories,
      previewLink: volumeInfo.previewLink,
      infoLink: volumeInfo.infoLink,
    },
  }
}

// Enhanced search with better queries for popular books
export async function searchGoogleBooks(query: string, maxResults = 40, startIndex = 0): Promise<Book[]> {
  try {
    const url = `${GOOGLE_BOOKS_API_BASE}?q=${encodeURIComponent(query)}&maxResults=${maxResults}&startIndex=${startIndex}&orderBy=relevance&printType=books`
    const response = await fetch(url)

    if (!response.ok) {
      throw new Error("Failed to fetch books")
    }

    const data = await response.json()

    if (!data.items) {
      return []
    }

    return data.items.map(convertGoogleBookToBook)
  } catch (error) {
    console.error("Error fetching books from Google Books API:", error)
    return []
  }
}

// Get books by category with better search terms
export async function getBooksByCategory(category: string, maxResults = 40): Promise<Book[]> {
  const categoryQueries: { [key: string]: string } = {
    Fiction: "fiction bestseller",
    "Science Fiction": "science fiction bestseller",
    Fantasy: "fantasy bestseller",
    Mystery: "mystery thriller bestseller",
    Romance: "romance bestseller",
    "Non-Fiction": "nonfiction bestseller",
    Biography: "biography memoir",
    History: "history bestseller",
    "Self-Help": "self help bestseller",
    Business: "business bestseller",
    Technology: "technology programming",
    Health: "health wellness",
    Travel: "travel guide",
    Cooking: "cookbook cooking",
    Art: "art design",
    Philosophy: "philosophy",
    Psychology: "psychology",
    Education: "education learning",
  }

  const searchQuery = categoryQueries[category] || `subject:${category}`
  return searchGoogleBooks(searchQuery, maxResults)
}

// Get trending/popular books with specific bestseller queries
export async function getTrendingBooks(): Promise<Book[]> {
  const queries = [
    "bestseller fiction 2024",
    "bestseller nonfiction 2024",
    "popular science fiction",
    "trending mystery thriller",
    "bestseller romance",
    "popular fantasy books",
    "bestseller biography",
    "popular self help",
  ]

  const allBooks: Book[] = []

  for (const query of queries) {
    try {
      const books = await searchGoogleBooks(query, 8)
      allBooks.push(...books)
    } catch (error) {
      console.error(`Error fetching books for query "${query}":`, error)
    }
  }

  // Remove duplicates and limit results
  const uniqueBooks = allBooks.filter((book, index, self) => index === self.findIndex((b) => b.isbn === book.isbn))

  return uniqueBooks.slice(0, 40)
}

// Get books by language with better search terms
export async function getBooksByLanguage(language: string): Promise<Book[]> {
  const languageQueries: { [key: string]: string } = {
    hi: "hindi literature bestseller",
    te: "telugu literature popular",
    ta: "tamil literature bestseller",
    bn: "bengali literature popular",
    mr: "marathi literature",
    gu: "gujarati literature",
    kn: "kannada literature",
    ml: "malayalam literature",
    pa: "punjabi literature",
  }

  const query = languageQueries[language] || `language:${language} bestseller`
  return searchGoogleBooks(query, 20)
}

// Get book details by ID
export async function getBookById(id: string): Promise<Book | null> {
  try {
    const url = `${GOOGLE_BOOKS_API_BASE}/${id}`
    const response = await fetch(url)

    if (!response.ok) {
      throw new Error("Failed to fetch book details")
    }

    const data = await response.json()
    return convertGoogleBookToBook(data)
  } catch (error) {
    console.error("Error fetching book details:", error)
    return null
  }
}

// Search for specific popular books to ensure we have good data
export async function getPopularBooks(): Promise<Book[]> {
  const popularTitles = [
    "The Seven Husbands of Evelyn Hugo",
    "Where the Crawdads Sing",
    "Atomic Habits",
    "The Silent Patient",
    "Educated Tara Westover",
    "Becoming Michelle Obama",
    "The Midnight Library",
    "Project Hail Mary",
    "Klara and the Sun",
    "The Thursday Murder Club",
    "Normal People",
    "Circe Madeline Miller",
    "The Invisible Life of Addie LaRue",
    "The Guest List",
    "The Sanatorium",
  ]

  const allBooks: Book[] = []

  for (const title of popularTitles) {
    try {
      const books = await searchGoogleBooks(title, 1)
      if (books.length > 0) {
        allBooks.push(books[0])
      }
    } catch (error) {
      console.error(`Error fetching "${title}":`, error)
    }
  }

  return allBooks
}
