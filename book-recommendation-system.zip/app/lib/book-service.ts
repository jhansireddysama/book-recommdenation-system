import {
  searchGoogleBooks,
  getTrendingBooks,
  getBooksByCategory,
  getBookById as getGoogleBookById,
  getPopularBooks,
  type Book,
} from "./google-books-api"
import {
  booksData,
  searchBooks as searchLocalBooks,
  getBooksByGenre,
  getTopRatedBooks,
  getBookById as getLocalBookById,
} from "./books-data"

export class BookService {
  // Enhanced search that prioritizes API results
  static async searchBooks(query: string, useAPI = true): Promise<Book[]> {
    if (!useAPI) {
      return searchLocalBooks(query)
    }

    try {
      // Get API results first (they have images and prices)
      const apiResults = await searchGoogleBooks(query, 30)

      // Get local results as fallback
      const localResults = searchLocalBooks(query)

      // Combine with API results taking priority
      const combined = [...apiResults, ...localResults]

      // Remove duplicates based on title and author similarity
      const unique = combined.filter((book, index, self) => {
        return (
          index ===
          self.findIndex(
            (b) =>
              b.title.toLowerCase() === book.title.toLowerCase() ||
              (b.isbn === book.isbn && book.isbn !== `google-${book.id}`),
          )
        )
      })

      return unique.slice(0, 50)
    } catch (error) {
      console.error("Error in enhanced search:", error)
      return searchLocalBooks(query)
    }
  }

  // Get trending books with real data
  static async getTrendingBooks(): Promise<Book[]> {
    try {
      // Get trending books from API
      const apiTrending = await getTrendingBooks()

      // Get popular books as additional content
      const popularBooks = await getPopularBooks()

      // Combine and deduplicate
      const combined = [...apiTrending, ...popularBooks]
      const unique = combined.filter((book, index, self) => index === self.findIndex((b) => b.isbn === book.isbn))

      // If we don't have enough, supplement with local top-rated
      if (unique.length < 20) {
        const localTrending = getTopRatedBooks(20)
        unique.push(...localTrending.slice(0, 20 - unique.length))
      }

      return unique.slice(0, 40)
    } catch (error) {
      console.error("Error fetching trending books:", error)
      return getTopRatedBooks(20)
    }
  }

  // Get books by genre with real data
  static async getBooksByGenre(genre: string): Promise<Book[]> {
    try {
      // Get API books first
      const apiBooks = await getBooksByCategory(genre)

      // Get local books as supplement
      const localBooks = getBooksByGenre(genre)

      // Combine and deduplicate
      const combined = [...apiBooks, ...localBooks]
      const unique = combined.filter((book, index, self) => index === self.findIndex((b) => b.isbn === book.isbn))

      return unique.slice(0, 30)
    } catch (error) {
      console.error(`Error fetching books for genre ${genre}:`, error)
      return getBooksByGenre(genre)
    }
  }

  // Enhanced personalized recommendations
  static async getPersonalizedRecommendations(userPreferences: {
    genres: string[]
    languages: string[]
  }): Promise<Book[]> {
    const { genres, languages } = userPreferences
    const recommendations: Book[] = []

    try {
      // Get books from user's preferred genres using API
      for (const genre of genres.slice(0, 3)) {
        const genreBooks = await this.getBooksByGenre(genre)
        const topGenreBooks = genreBooks.sort((a, b) => b.rating - a.rating).slice(0, 4)
        recommendations.push(...topGenreBooks)
      }

      // Add some trending books for variety
      const trending = await this.getTrendingBooks()
      recommendations.push(...trending.slice(0, 5))

      // Remove duplicates and score
      const unique = recommendations.filter((book, index, self) => index === self.findIndex((b) => b.id === book.id))

      // Score books based on user preferences
      const scored = unique.map((book) => ({
        ...book,
        score:
          (genres.some((g) => book.genres.some((bg) => bg.toLowerCase().includes(g.toLowerCase()))) ? 3 : 0) +
          (languages.includes(book.language) ? 2 : 0) +
          (book.rating >= 4.0 ? 2 : 0) +
          (book.imageUrl ? 1 : 0) + // Prefer books with images
          (book.price ? 1 : 0), // Prefer books with price info
      }))

      return scored.sort((a, b) => b.score - a.score).slice(0, 20)
    } catch (error) {
      console.error("Error getting personalized recommendations:", error)
      // Fallback to local recommendations
      return this.getLocalPersonalizedRecommendations(userPreferences)
    }
  }

  // Fallback local recommendations
  private static getLocalPersonalizedRecommendations(userPreferences: {
    genres: string[]
    languages: string[]
  }): Book[] {
    const { genres, languages } = userPreferences
    const recommendations: Book[] = []

    for (const genre of genres) {
      const genreBooks = getBooksByGenre(genre)
      recommendations.push(...genreBooks.slice(0, 3))
    }

    for (const language of languages) {
      const langBooks = booksData
        .filter((book) => book.language === language)
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 2)
      recommendations.push(...langBooks)
    }

    const unique = recommendations.filter((book, index, self) => index === self.findIndex((b) => b.id === book.id))

    return unique.slice(0, 15)
  }

  // Get book by ID (check both API and local)
  static async getBookById(id: string): Promise<Book | undefined> {
    // First check local data
    const localBook = getLocalBookById(id)
    if (localBook) {
      return localBook
    }

    // If not found locally, try Google Books API
    try {
      const apiBook = await getGoogleBookById(id)
      return apiBook || undefined
    } catch (error) {
      console.error(`Error fetching book ${id}:`, error)
      return undefined
    }
  }

  // Get all available books (prioritize API books)
  static getAllBooks(): Book[] {
    return booksData
  }

  // Get books by language
  static getBooksByLanguage(language: string): Book[] {
    return booksData.filter((book) => book.language === language)
  }

  // Initialize popular books cache
  static async initializePopularBooks(): Promise<void> {
    try {
      const popular = await getPopularBooks()
      console.log(`Loaded ${popular.length} popular books with real data`)
    } catch (error) {
      console.error("Error initializing popular books:", error)
    }
  }
}
