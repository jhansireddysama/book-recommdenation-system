"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Heart, Star, ArrowLeft, Trash2, BookMarked, Search } from "lucide-react"
import Link from "next/link"
import { booksData } from "../lib/books-data"

export default function WishlistPage() {
  const [wishlistBooks, setWishlistBooks] = useState<any[]>([])
  const [currentUser, setCurrentUser] = useState<any>(null)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (user) {
      const userData = JSON.parse(user)
      setCurrentUser(userData)

      const wishlist = userData.wishlist || []
      const books = booksData.filter((book) => wishlist.includes(book.id))
      setWishlistBooks(books)
    }
  }, [])

  const removeFromWishlist = (bookId: string) => {
    const updatedWishlist = currentUser.wishlist.filter((id: string) => id !== bookId)
    const updatedUser = { ...currentUser, wishlist: updatedWishlist }

    localStorage.setItem("currentUser", JSON.stringify(updatedUser))
    setCurrentUser(updatedUser)
    setWishlistBooks((prev) => prev.filter((book) => book.id !== bookId))

    // Update in users array
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }
  }

  const addToMyBooks = (bookId: string) => {
    const myBooks = currentUser.myBooks || []
    if (!myBooks.includes(bookId)) {
      const updatedUser = { ...currentUser, myBooks: [...myBooks, bookId] }
      localStorage.setItem("currentUser", JSON.stringify(updatedUser))
      setCurrentUser(updatedUser)

      // Update in users array
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
      if (userIndex !== -1) {
        users[userIndex] = updatedUser
        localStorage.setItem("users", JSON.stringify(users))
      }
    }
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Please log in to view your wishlist</p>
          <Link href="/login">
            <Button className="mt-4">Go to Login</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <Heart className="h-6 w-6 text-red-500" />
            <span className="text-xl font-bold">My Wishlist</span>
            <Badge variant="secondary">{wishlistBooks.length} books</Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {wishlistBooks.length === 0 ? (
          <div className="text-center py-12">
            <Heart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Your wishlist is empty</h3>
            <p className="text-gray-600 mb-6">Start adding books you want to read later</p>
            <Link href="/search">
              <Button>
                <Search className="h-4 w-4 mr-2" />
                Browse Books
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {wishlistBooks.map((book) => (
              <Card key={book.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <div className="aspect-[3/4] bg-gradient-to-br from-red-100 to-pink-100 rounded-lg mb-3 flex items-center justify-center">
                    <BookOpen className="h-12 w-12 text-red-600" />
                  </div>
                  <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
                  <CardDescription>by {book.author}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 mr-1" />
                        <span className="text-sm font-medium">{book.rating}</span>
                      </div>
                      <Badge variant="outline">{book.genres[0]}</Badge>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {book.genres.slice(0, 2).map((genre: string) => (
                        <Badge key={genre} variant="secondary" className="text-xs">
                          {genre}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex space-x-2">
                      <Link href={`/book/${book.id}`} className="flex-1">
                        <Button size="sm" className="w-full">
                          View Details
                        </Button>
                      </Link>
                      <Button size="sm" variant="outline" onClick={() => addToMyBooks(book.id)} title="Add to My Books">
                        <BookMarked className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => removeFromWishlist(book.id)}
                        title="Remove from Wishlist"
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
