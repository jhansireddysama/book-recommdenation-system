"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"

const genres = [
  "Fiction",
  "Non-Fiction",
  "Mystery",
  "Romance",
  "Science Fiction",
  "Fantasy",
  "Biography",
  "History",
  "Self-Help",
  "Business",
  "Technology",
  "Health",
  "Travel",
  "Cooking",
  "Art",
  "Philosophy",
  "Psychology",
  "Education",
]

const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "te", name: "Telugu" },
  { code: "ta", name: "Tamil" },
  { code: "bn", name: "Bengali" },
  { code: "mr", name: "Marathi" },
  { code: "gu", name: "Gujarati" },
  { code: "kn", name: "Kannada" },
  { code: "ml", name: "Malayalam" },
  { code: "pa", name: "Punjabi" },
]

export default function OnboardingPage() {
  const [step, setStep] = useState(1)
  const [selectedGenres, setSelectedGenres] = useState<string[]>([])
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(["en"])
  const [readingGoal, setReadingGoal] = useState(12)
  const router = useRouter()

  const handleGenreToggle = (genre: string) => {
    setSelectedGenres((prev) => (prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]))
  }

  const handleLanguageToggle = (langCode: string) => {
    setSelectedLanguages((prev) => (prev.includes(langCode) ? prev.filter((l) => l !== langCode) : [...prev, langCode]))
  }

  const handleComplete = () => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const updatedUser = {
      ...currentUser,
      preferences: {
        genres: selectedGenres,
        languages: selectedLanguages,
        readingGoal,
      },
    }

    localStorage.setItem("currentUser", JSON.stringify(updatedUser))

    // Update in users array
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
    if (userIndex !== -1) {
      users[userIndex] = updatedUser
      localStorage.setItem("users", JSON.stringify(users))
    }

    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <BookOpen className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold">ReadSphere</span>
          </div>
          <CardTitle>Let's Personalize Your Experience</CardTitle>
          <CardDescription>Help us recommend the perfect books for you</CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">What genres do you enjoy?</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {genres.map((genre) => (
                    <Badge
                      key={genre}
                      variant={selectedGenres.includes(genre) ? "default" : "outline"}
                      className="cursor-pointer p-2 text-center justify-center"
                      onClick={() => handleGenreToggle(genre)}
                    >
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <div className="text-sm text-gray-500">Step 1 of 3</div>
                <Button onClick={() => setStep(2)} disabled={selectedGenres.length === 0}>
                  Next <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Which languages do you prefer?</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {languages.map((lang) => (
                    <Badge
                      key={lang.code}
                      variant={selectedLanguages.includes(lang.code) ? "default" : "outline"}
                      className="cursor-pointer p-2 text-center justify-center"
                      onClick={() => handleLanguageToggle(lang.code)}
                    >
                      {lang.name}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
                <div className="text-sm text-gray-500">Step 2 of 3</div>
                <Button onClick={() => setStep(3)} disabled={selectedLanguages.length === 0}>
                  Next <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">What's your reading goal for this year?</h3>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                  {[6, 12, 24, 36, 50, 100].map((goal) => (
                    <Badge
                      key={goal}
                      variant={readingGoal === goal ? "default" : "outline"}
                      className="cursor-pointer p-3 text-center justify-center"
                      onClick={() => setReadingGoal(goal)}
                    >
                      {goal} books
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  Back
                </Button>
                <div className="text-sm text-gray-500">Step 3 of 3</div>
                <Button onClick={handleComplete}>Complete Setup</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
