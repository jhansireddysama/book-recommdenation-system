"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BookOpen, Search, Filter, Star, Heart, ArrowLeft, X, History, TrendingUp } from "lucide-react"
import Link from "next/link"
import { booksData } from "../lib/books-data"
import { BookService } from "../lib/book-service"

const genres = [
  "All Genres",
  "Fiction",
  "Non-Fiction",
  "Mystery",
  "Romance",
  "Science Fiction",
  "Fantasy",
  "Biography",
  "History",
  "Self-Help",
  "Business",
  "Technology",
]

const languages = [
  { code: "all", name: "All Languages" },
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "te", name: "Telugu" },
  { code: "ta", name: "Tamil" },
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedGenre, setSelectedGenre] = useState("All Genres")
  const [selectedLanguage, setSelectedLanguage] = useState("all")
  const [sortBy, setSortBy] = useState("relevance")
  const [filteredBooks, setFilteredBooks] = useState(booksData)
  const [searchHistory, setSearchHistory] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [trendingBooks, setTrendingBooks] = useState<any[]>([])
  const [isLoadingTrending, setIsLoadingTrending] = useState(true)

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const query = urlParams.get("q")
    if (query) {
      setSearchQuery(query)
      performSearch(query)
    } else {
      // Load trending books when no search query
      loadTrendingBooks()
    }

    // Load search history
    const history = JSON.parse(localStorage.getItem("searchHistory") || "[]")
    setSearchHistory(history)
  }, [])

  const loadTrendingBooks = async () => {
    try {
      setIsLoadingTrending(true)
      const trending = await BookService.getTrendingBooks()
      setTrendingBooks(trending.slice(0, 20))
    } catch (error) {
      console.error("Error loading trending books:", error)
      const fallback = BookService.getAllBooks()
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 20)
      setTrendingBooks(fallback)
    } finally {
      setIsLoadingTrending(false)
    }
  }

  const performSearch = async (query: string = searchQuery) => {
    let results = []

    // Use enhanced search with API integration
    if (query.trim()) {
      try {
        results = await BookService.searchBooks(query, true) // true enables API search
      } catch (error) {
        console.error("Search error:", error)
        results = BookService.getAllBooks().filter(
          (book) =>
            book.title.toLowerCase().includes(query.toLowerCase()) ||
            book.author.toLowerCase().includes(query.toLowerCase()) ||
            book.genres.some((genre) => genre.toLowerCase().includes(query.toLowerCase())) ||
            book.isbn.includes(query),
        )
      }

      // Save to search history
      const history = JSON.parse(localStorage.getItem("searchHistory") || "[]")
      const updatedHistory = [query, ...history.filter((h: string) => h !== query)].slice(0, 5)
      localStorage.setItem("searchHistory", JSON.stringify(updatedHistory))
      setSearchHistory(updatedHistory)
    } else {
      results = trendingBooks
    }

    // Apply filters
    if (selectedGenre !== "All Genres") {
      results = results.filter((book) => book.genres.some((genre: string) => genre.includes(selectedGenre)))
    }

    if (selectedLanguage !== "all") {
      results = results.filter((book) => book.language === selectedLanguage)
    }

    // Sort results
    switch (sortBy) {
      case "rating":
        results.sort((a, b) => b.rating - a.rating)
        break
      case "year":
        results.sort((a, b) => b.publishedYear - a.publishedYear)
        break
      case "title":
        results.sort((a, b) => a.title.localeCompare(b.title))
        break
      case "author":
        results.sort((a, b) => a.author.localeCompare(b.author))
        break
    }

    setFilteredBooks(results)
  }

  const handleSearch = () => {
    performSearch()
  }

  const addToWishlist = (bookId: string) => {
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    const wishlist = currentUser.wishlist || []

    if (!wishlist.includes(bookId)) {
      wishlist.push(bookId)
      currentUser.wishlist = wishlist
      localStorage.setItem("currentUser", JSON.stringify(currentUser))

      // Update in users array
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: any) => u.id === currentUser.id)
      if (userIndex !== -1) {
        users[userIndex] = currentUser
        localStorage.setItem("users", JSON.stringify(users))
      }
    }
  }

  const clearSearchHistory = () => {
    localStorage.removeItem("searchHistory")
    setSearchHistory([])
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <BookOpen className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">Advanced Search</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Search Bar */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search by title, author, genre, or ISBN..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch}>
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>

            {/* Search History */}
            {searchHistory.length > 0 && (
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600 flex items-center">
                    <History className="h-4 w-4 mr-1" />
                    Recent Searches
                  </span>
                  <Button variant="ghost" size="sm" onClick={clearSearchHistory}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {searchHistory.map((query, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="cursor-pointer"
                      onClick={() => {
                        setSearchQuery(query)
                        performSearch(query)
                      }}
                    >
                      {query}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Filters */}
            {showFilters && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Genre</label>
                    <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {genres.map((genre) => (
                          <SelectItem key={genre} value={genre}>
                            {genre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Language</label>
                    <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {languages.map((lang) => (
                          <SelectItem key={lang.code} value={lang.code}>
                            {lang.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Sort By</label>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relevance">Relevance</SelectItem>
                        <SelectItem value="rating">Rating</SelectItem>
                        <SelectItem value="year">Publication Year</SelectItem>
                        <SelectItem value="title">Title</SelectItem>
                        <SelectItem value="author">Author</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="mt-4 flex space-x-2">
                  <Button onClick={performSearch}>Apply Filters</Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedGenre("All Genres")
                      setSelectedLanguage("all")
                      setSortBy("relevance")
                      setFilteredBooks(booksData)
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Filters */}
        {(selectedGenre !== "All Genres" || selectedLanguage !== "all" || searchQuery) && (
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-sm text-gray-600">Active filters:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {searchQuery && (
                <Badge variant="secondary">
                  Search: "{searchQuery}"
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => {
                      setSearchQuery("")
                      performSearch("")
                    }}
                  />
                </Badge>
              )}
              {selectedGenre !== "All Genres" && (
                <Badge variant="secondary">
                  Genre: {selectedGenre}
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => {
                      setSelectedGenre("All Genres")
                      performSearch()
                    }}
                  />
                </Badge>
              )}
              {selectedLanguage !== "all" && (
                <Badge variant="secondary">
                  Language: {languages.find((l) => l.code === selectedLanguage)?.name}
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => {
                      setSelectedLanguage("all")
                      performSearch()
                    }}
                  />
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Trending Books Section - Show when no search query */}
        {!searchQuery && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <TrendingUp className="h-6 w-6 text-orange-500 mr-2" />
              Trending Books
            </h2>
            {isLoadingTrending ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {Array.from({ length: 8 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader className="pb-2">
                      <div className="aspect-[3/4] bg-gray-200 rounded-lg mb-3" />
                      <div className="h-4 bg-gray-200 rounded mb-2" />
                      <div className="h-3 bg-gray-200 rounded w-2/3" />
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {trendingBooks.slice(0, 8).map((book) => (
                  <Card key={book.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="aspect-[3/4] bg-gradient-to-br from-orange-100 to-red-100 rounded-lg mb-3 flex items-center justify-center">
                        <BookOpen className="h-12 w-12 text-orange-600" />
                      </div>
                      <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
                      <CardDescription>by {book.author}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 mr-1" />
                            <span className="text-sm font-medium">{book.rating}</span>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {book.publishedYear}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {book.genres.slice(0, 2).map((genre: string) => (
                            <Badge key={genre} variant="secondary" className="text-xs">
                              {genre}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Link href={`/book/${book.id}`} className="flex-1">
                          <Button size="sm" className="w-full">
                            View Details
                          </Button>
                        </Link>
                        <Button size="sm" variant="outline" onClick={() => addToWishlist(book.id)}>
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Results */}
        <div className="mb-4">
          <p className="text-gray-600">
            Found {filteredBooks.length} book{filteredBooks.length !== 1 ? "s" : ""}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredBooks.map((book) => (
            <Card key={book.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-2">
                <div className="aspect-[3/4] bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mb-3 flex items-center justify-center">
                  <BookOpen className="h-12 w-12 text-blue-600" />
                </div>
                <CardTitle className="text-lg line-clamp-2">{book.title}</CardTitle>
                <CardDescription>by {book.author}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm font-medium">{book.rating}</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {book.publishedYear}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {book.genres.slice(0, 2).map((genre) => (
                      <Badge key={genre} variant="secondary" className="text-xs">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Link href={`/book/${book.id}`} className="flex-1">
                    <Button size="sm" className="w-full">
                      View Details
                    </Button>
                  </Link>
                  <Button size="sm" variant="outline" onClick={() => addToWishlist(book.id)}>
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredBooks.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No books found</h3>
            <p className="text-gray-600">Try adjusting your search criteria or filters</p>
          </div>
        )}
      </div>
    </div>
  )
}
